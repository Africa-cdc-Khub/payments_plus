# CPHIA 2025 Laravel Email Service Package

A Laravel-compatible email service for sending emails using Microsoft Graph API with OAuth 2.0 authentication.

## Features

- ✅ OAuth 2.0 Authorization Code Flow
- ✅ Automatic token refresh
- ✅ Pre-built email templates
- ✅ Laravel service container integration
- ✅ Queue support for background emails
- ✅ Error handling and logging
- ✅ Clean, reusable API

## Installation

1. **Copy the package files** to your Laravel project:
   - Copy `src/` folder to your Laravel app
   - Copy `EmailServiceProvider.php` to `app/Providers/`

2. **Register the Service Provider** in `config/app.php`:
   ```php
   'providers' => [
       // ... other providers
       App\Providers\EmailServiceProvider::class,
   ],
   ```

3. **Add environment variables** to your `.env` file:
   ```env
   # CPHIA 2025 Email Service Configuration
   MAIL_DRIVER=exchange_oauth
   EXCHANGE_TENANT_ID=ace5c645-3ec7-4c8e-b12e-077221505df5
   EXCHANGE_CLIENT_ID=996dc2ed-b7c6-446d-a2ee-3b05e935e850
   EXCHANGE_CLIENT_SECRET=dA48Q~0GTzAnUoPJFMK2lOTThgdugnR5fC4l6b0T
   EXCHANGE_REDIRECT_URI=http://localhost/payments_plus/auth/callback.php
   EXCHANGE_SCOPE=https://graph.microsoft.com/Mail.Send
   MAIL_FROM_ADDRESS=notifications@africacdc.org
   MAIL_FROM_NAME=CPHIA 2025
   ```

4. **Create the database table** for OAuth tokens:
   ```sql
   CREATE TABLE IF NOT EXISTS oauth_tokens (
       id INT AUTO_INCREMENT PRIMARY KEY,
       service VARCHAR(50) NOT NULL,
       client_id VARCHAR(255) NOT NULL,
       access_token TEXT NOT NULL,
       refresh_token TEXT,
       expires_at TIMESTAMP NOT NULL,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       INDEX idx_service (service)
   );
   ```

## OAuth Setup (One-Time Only)

**You only need to complete OAuth authentication ONCE!** After that, tokens auto-refresh automatically.

1. **Add OAuth routes** to `routes/web.php`:
   ```php
   use Cphia2025\LaravelEmailService;

   Route::get('/email/oauth', function (LaravelEmailService $emailService) {
       if (!$emailService->isConfigured()) {
           return response()->json(['error' => 'Email service not configured'], 500);
       }
       
       if ($emailService->hasValidTokens()) {
           return response()->json(['message' => 'OAuth already configured']);
       }
       
       $oauthUrl = $emailService->getOAuthUrl();
       return redirect($oauthUrl);
   });

   Route::get('/email/oauth/callback', function (Request $request, LaravelEmailService $emailService) {
       $code = $request->get('code');
       $state = $request->get('state');
       
       if (!$code || !$state) {
           return response()->json(['error' => 'Invalid callback parameters'], 400);
       }
       
       try {
           $success = $emailService->processOAuthCallback($code, $state);
           
           if ($success) {
               return response()->json(['message' => 'OAuth setup successful!']);
           } else {
               return response()->json(['error' => 'OAuth setup failed'], 500);
           }
       } catch (\Exception $e) {
           return response()->json(['error' => $e->getMessage()], 500);
       }
   });
   ```

2. **Complete OAuth setup** by visiting `/email/oauth` in your browser

3. **That's it!** Tokens will auto-refresh automatically - no more user interaction needed!

## Usage

### Basic Email Sending

```php
use Cphia2025\LaravelEmailService;

class RegistrationController extends Controller
{
    protected $emailService;
    
    public function __construct(LaravelEmailService $emailService)
    {
        $this->emailService = $emailService;
    }
    
    public function store(Request $request)
    {
        // ... registration logic
        
        // Send confirmation email
        $this->emailService->sendEmail(
            $request->email,
            'Registration Confirmation',
            '<h1>Thank you for registering!</h1>'
        );
    }
}
```

### Pre-built Email Templates

```php
// Registration confirmation
$registrationData = [
    'name' => 'John Doe',
    'package' => 'Conference Package',
    'amount' => '$200',
    'registration_id' => 'REG-12345',
];

$emailService->sendRegistrationConfirmation($email, $registrationData);

// Payment confirmation
$paymentData = [
    'name' => 'John Doe',
    'amount' => '$200',
    'transaction_id' => 'TXN-12345',
    'payment_method' => 'Credit Card',
];

$emailService->sendPaymentConfirmation($email, $paymentData);

// Admin notification
$notificationData = [
    'type' => 'New Registration',
    'name' => 'John Doe',
    'email' => 'john@example.com',
    'details' => 'Conference Package registration',
];

$emailService->sendAdminNotification('admin@example.com', $notificationData);
```

### Queue Support

```php
use App\Jobs\SendRegistrationEmail;

// Dispatch email to queue
SendRegistrationEmail::dispatch($email, $registrationData);
```

## Important Notes

### OAuth Authentication
- **One-time setup only** - Complete OAuth authentication once
- **Automatic token refresh** - Tokens refresh automatically
- **No user interaction needed** after initial setup
- **Secure** - Uses OAuth 2.0 best practices

### Database Requirements
- Requires `oauth_tokens` table for token storage
- Tokens are encrypted and stored securely
- Automatic cleanup of expired tokens

### Error Handling
- All methods return boolean for success/failure
- Exceptions are logged automatically
- Graceful fallback for token refresh failures

## Troubleshooting

1. **"Email service not configured"** - Check environment variables
2. **"No valid OAuth tokens"** - Complete OAuth setup at `/email/oauth`
3. **"Token refresh failed"** - Re-run OAuth setup
4. **Email sending fails** - Check Microsoft Graph API permissions

## Support

For issues or questions, check the error logs and ensure all environment variables are correctly set.
