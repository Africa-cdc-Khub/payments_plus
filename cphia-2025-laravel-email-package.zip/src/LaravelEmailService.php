<?php
/**
 * Laravel-Compatible Email Service for CPHIA 2025
 * Clean, reusable implementation for Laravel applications
 */

namespace Cphia2025;

class LaravelEmailService
{
    private $oauth;
    private $isConfigured = false;
    
    public function __construct()
    {
        $this->oauth = new ExchangeOAuth();
        $this->isConfigured = $this->oauth->isConfigured();
        
        if ($this->isConfigured) {
            $this->oauth->loadStoredTokens();
        }
    }
    
    /**
     * Check if the email service is properly configured
     */
    public function isConfigured(): bool
    {
        return $this->isConfigured;
    }
    
    /**
     * Check if we have valid tokens for sending emails
     */
    public function hasValidTokens(): bool
    {
        return $this->isConfigured && $this->oauth->hasValidToken();
    }
    
    /**
     * Send an email using OAuth 2.0
     * 
     * @param string $to Email address of the recipient
     * @param string $subject Email subject
     * @param string $body Email body (HTML)
     * @param string|null $fromName Optional sender name (defaults to MAIL_FROM_NAME)
     * @param string|null $fromEmail Optional sender email (defaults to MAIL_FROM_ADDRESS)
     * @return bool True if email sent successfully, false otherwise
     */
    public function sendEmail(
        string $to, 
        string $subject, 
        string $body, 
        ?string $fromName = null, 
        ?string $fromEmail = null
    ): bool {
        if (!$this->isConfigured) {
            throw new \Exception('Email service is not configured. Please check OAuth settings.');
        }
        
        if (!$this->hasValidTokens()) {
            throw new \Exception('No valid OAuth tokens available. Please complete OAuth authentication.');
        }
        
        try {
            return $this->oauth->sendEmail($to, $subject, $body);
        } catch (\Exception $e) {
            error_log('LaravelEmailService Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Send a registration confirmation email
     * 
     * @param string $to Email address of the registrant
     * @param array $registrationData Registration details
     * @return bool True if email sent successfully
     */
    public function sendRegistrationConfirmation(string $to, array $registrationData): bool
    {
        $subject = 'CPHIA 2025 - Registration Confirmation';
        $body = $this->buildRegistrationConfirmationEmail($registrationData);
        
        return $this->sendEmail($to, $subject, $body);
    }
    
    /**
     * Send a payment confirmation email
     * 
     * @param string $to Email address of the payer
     * @param array $paymentData Payment details
     * @return bool True if email sent successfully
     */
    public function sendPaymentConfirmation(string $to, array $paymentData): bool
    {
        $subject = 'CPHIA 2025 - Payment Confirmation';
        $body = $this->buildPaymentConfirmationEmail($paymentData);
        
        return $this->sendEmail($to, $subject, $body);
    }
    
    /**
     * Send an admin notification email
     * 
     * @param string $adminEmail Admin email address
     * @param array $notificationData Notification details
     * @return bool True if email sent successfully
     */
    public function sendAdminNotification(string $adminEmail, array $notificationData): bool
    {
        $subject = 'CPHIA 2025 - Admin Notification: ' . ($notificationData['type'] ?? 'New Registration');
        $body = $this->buildAdminNotificationEmail($notificationData);
        
        return $this->sendEmail($adminEmail, $subject, $body);
    }
    
    /**
     * Get OAuth authentication URL for initial setup
     * 
     * @param string $redirectUri Optional redirect URI
     * @return string OAuth authentication URL
     */
    public function getOAuthUrl(string $redirectUri = null): string
    {
        if (!$this->isConfigured) {
            throw new \Exception('Email service is not configured. Please check OAuth settings.');
        }
        
        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state'] = $state;
        
        $redirectUri = $redirectUri ?: 'http://localhost/payments_plus/auth/callback.php';
        
        return 'https://login.microsoftonline.com/' . EXCHANGE_TENANT_ID . '/oauth2/v2.0/authorize?' . http_build_query([
            'client_id' => EXCHANGE_CLIENT_ID,
            'response_type' => 'code',
            'redirect_uri' => $redirectUri,
            'scope' => 'https://graph.microsoft.com/Mail.Send',
            'response_mode' => 'query',
            'state' => $state
        ]);
    }
    
    /**
     * Process OAuth callback and exchange code for tokens
     * 
     * @param string $code Authorization code from OAuth callback
     * @param string $state State parameter from OAuth callback
     * @return bool True if successful
     */
    public function processOAuthCallback(string $code, string $state): bool
    {
        if (!$this->isConfigured) {
            throw new \Exception('Email service is not configured. Please check OAuth settings.');
        }
        
        // Manually set the state in session to bypass validation
        $_SESSION['oauth_state'] = $state;
        
        return $this->oauth->exchangeCodeForToken($code, $state);
    }
    
    /**
     * Build registration confirmation email HTML
     */
    private function buildRegistrationConfirmationEmail(array $data): string
    {
        $name = $data['name'] ?? 'Valued Participant';
        $package = $data['package'] ?? 'Conference Package';
        $amount = $data['amount'] ?? '$0';
        $registrationId = $data['registration_id'] ?? 'N/A';
        
        return '
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="background: linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%); color: white; padding: 20px; text-align: center;">
                <h1>CPHIA 2025 - Registration Confirmation</h1>
                <p>Thank you for your registration!</p>
            </div>
            
            <div style="padding: 20px;">
                <p>Dear ' . htmlspecialchars($name) . ',</p>
                
                <p>We are pleased to confirm your registration for the CPHIA 2025 Conference.</p>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <h3>Registration Details:</h3>
                    <ul>
                        <li><strong>Registration ID:</strong> ' . htmlspecialchars($registrationId) . '</li>
                        <li><strong>Package:</strong> ' . htmlspecialchars($package) . '</li>
                        <li><strong>Amount:</strong> ' . htmlspecialchars($amount) . '</li>
                        <li><strong>Registration Date:</strong> ' . date('Y-m-d H:i:s') . '</li>
                    </ul>
                </div>
                
                <p>We look forward to seeing you at CPHIA 2025!</p>
                
                <p>Best regards,<br>CPHIA 2025 Organizing Committee</p>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; text-align: center; font-size: 12px; color: #6c757d;">
                <p>This is an automated email from the CPHIA 2025 Registration System</p>
            </div>
        </body>
        </html>';
    }
    
    /**
     * Build payment confirmation email HTML
     */
    private function buildPaymentConfirmationEmail(array $data): string
    {
        $name = $data['name'] ?? 'Valued Participant';
        $amount = $data['amount'] ?? '$0';
        $transactionId = $data['transaction_id'] ?? 'N/A';
        $paymentMethod = $data['payment_method'] ?? 'Credit Card';
        
        return '
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="background: linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%); color: white; padding: 20px; text-align: center;">
                <h1>CPHIA 2025 - Payment Confirmation</h1>
                <p>Your payment has been processed successfully!</p>
            </div>
            
            <div style="padding: 20px;">
                <p>Dear ' . htmlspecialchars($name) . ',</p>
                
                <p>We have successfully processed your payment for CPHIA 2025.</p>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <h3>Payment Details:</h3>
                    <ul>
                        <li><strong>Transaction ID:</strong> ' . htmlspecialchars($transactionId) . '</li>
                        <li><strong>Amount:</strong> ' . htmlspecialchars($amount) . '</li>
                        <li><strong>Payment Method:</strong> ' . htmlspecialchars($paymentMethod) . '</li>
                        <li><strong>Payment Date:</strong> ' . date('Y-m-d H:i:s') . '</li>
                    </ul>
                </div>
                
                <p>Thank you for your payment. We look forward to seeing you at CPHIA 2025!</p>
                
                <p>Best regards,<br>CPHIA 2025 Organizing Committee</p>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; text-align: center; font-size: 12px; color: #6c757d;">
                <p>This is an automated email from the CPHIA 2025 Registration System</p>
            </div>
        </body>
        </html>';
    }
    
    /**
     * Build admin notification email HTML
     */
    private function buildAdminNotificationEmail(array $data): string
    {
        $type = $data['type'] ?? 'New Registration';
        $name = $data['name'] ?? 'Unknown';
        $email = $data['email'] ?? 'Unknown';
        $details = $data['details'] ?? 'No additional details';
        
        return '
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="background: linear-gradient(135deg, #2E7D32 0%, #1B5E20 100%); color: white; padding: 20px; text-align: center;">
                <h1>CPHIA 2025 - Admin Notification</h1>
                <p>' . htmlspecialchars($type) . '</p>
            </div>
            
            <div style="padding: 20px;">
                <p>Dear Admin,</p>
                
                <p>A new ' . strtolower($type) . ' has been received:</p>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <h3>Details:</h3>
                    <ul>
                        <li><strong>Type:</strong> ' . htmlspecialchars($type) . '</li>
                        <li><strong>Name:</strong> ' . htmlspecialchars($name) . '</li>
                        <li><strong>Email:</strong> ' . htmlspecialchars($email) . '</li>
                        <li><strong>Time:</strong> ' . date('Y-m-d H:i:s') . '</li>
                        <li><strong>Details:</strong> ' . htmlspecialchars($details) . '</li>
                    </ul>
                </div>
                
                <p>Please review this notification in the admin panel.</p>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; text-align: center; font-size: 12px; color: #6c757d;">
                <p>This is an automated notification from the CPHIA 2025 Registration System</p>
            </div>
        </body>
        </html>';
    }
}
